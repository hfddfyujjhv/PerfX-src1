package com.perfx.control

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.perfx.control.overlay.FpsOverlayService
import com.perfx.control.ui.TurboScreen
import com.perfx.control.ui.TurboViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App()
                }
            }
        }
    }
}

@Composable
fun App(vm: TurboViewModel = viewModel()) {
    val context = LocalContext.current
    val fpsOn by vm.fpsOverlayOn.collectAsState()
    TurboScreen(modifier = Modifier.padding(bottom = 8.dp))
    LaunchedEffect(fpsOn) {
        if (fpsOn) {
            if (!Settings.canDrawOverlays(context)) {
                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")))
                vm.fpsOverlayOn.value = false
            } else {
                FpsOverlayService.start(context)
            }
        } else {
            FpsOverlayService.stop(context)
        }
    }
}
