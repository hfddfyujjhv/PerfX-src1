package com.perfx.control.core

import com.perfx.control.root.RootShell

enum class PowerMode(val cmd: String, val label: String) {
    POWERSAVE("powersave", "省电"),
    BALANCE("balance", "均衡"),
    PERFORMANCE("performance", "性能"),
    FAST("fast", "极速"),
    PEDESTAL("pedestal", "狂暴")
}

object TurboEngine {

    private const val CFG_PATH = "/data/powercfg.json"
    private const val STATE_PATH = "/sdcard/Android/yc/uperf/cur_powermode.txt"
    private const val PERAPP_PATH = "/sdcard/Android/yc/uperf/perapp_powermode.txt"
    private const val INITSVC_PATH = "/data/adb/modules/uperf/script/initsvc.sh"

    /** 判断 Uperf 模块是否已安装 */
    suspend fun isUperfInstalled(): Boolean = RootShell.readFile(CFG_PATH).isNotBlank()

    /** 切换 Uperf 模式 */
    suspend fun setMode(mode: PowerMode): Boolean {
        val entry = parseEntry()
        return if (entry.isNotEmpty()) {
            RootShell.execOk("sh $entry ${mode.cmd}")
        } else {
            // 回退：直接写 cur_powermode.txt
            RootShell.writeFile(STATE_PATH, mode.cmd)
        }
    }

    /** 读取当前模式 */
    suspend fun currentMode(): PowerMode? {
        val raw = RootShell.readFile(STATE_PATH)
        return PowerMode.entries.firstOrNull { it.cmd == raw.trim() }
    }

    /** 获取 powercfg.json 里的 entry 路径 */
    suspend fun parseEntry(): String {
        val json = RootShell.readFile(CFG_PATH)
        if (json.isBlank()) return ""
        val m = Regex("\"entry\"\\s*:\\s*\"([^\"]+)\"").find(json)
        return m?.groupValues?.get(1) ?: "/data/powercfg.sh"
    }

    // ====== 刷新率管理 ======
    /** 设置屏幕刷新率为指定 Hz（144 / 120 / 60 / 自动） */
    suspend fun setRefreshRate(hz: Int): Boolean {
        // 小米/高通 MIUI：通过 sysfs 或 svc 设置
        val ok1 = RootShell.execOk("svc power set-refresh-rate $hz")
        // DRM 路径
        val ok2 = RootShell.execOk("echo $hz > /sys/class/graphics/fb0/refresh_rate 2>/dev/null")
        // 备用：通过 MIUI 的 display 设置
        val ok3 = RootShell.execOk("settings put system refresh_rate $hz 2>/dev/null")
        return ok1 || ok2 || ok3
    }

    /** 读取当前刷新率 */
    suspend fun getCurrentRefreshRate(): Int {
        // 从 sysfs
        var r = RootShell.readFile("/sys/class/graphics/fb0/refresh_rate").toIntOrNull()
        if (r != null && r > 0) return r
        // 从 wm info
        val out = RootShell.exec("dumpsys display 2>/dev/null | grep -m1 mCurrentState.mAnimationScale")
        // fallback: 尝试从 build.prop 读取 max refresh rate
        val maxR = RootShell.readFile("/sys/class/graphics/fb0/max_refresh_rate").toIntOrNull() ?: 144
        return maxR
    }

    // ====== 调度接管（核心：替代 Scene 的调度开关） ======
    /**
     * 接管调度：
     * 1. 停止 MIUI perfd / miuibooster 等降频服务
     * 2. 锁定 CPU 频率下限
     * 3. 关闭 GPU 降频策略
     * 4. 提升 I/O 优先级
     */
    suspend fun enableSchedulingTakeover(): Boolean {
        val cmds = listOf(
            // 停止 MIUI 降频服务
            "stop perfd",
            "stop miuibooster",
            "stop vendor.perfservice",
            "stop vendor.miperf",
            // 停止高负载时降频的热管理服务
            "stop thermal-engine 2>/dev/null",
            "stop vendor.thermal-hal-2-0.mtk 2>/dev/null",
            // 关闭 MIUI 的 perfd hint
            "echo '0' > /sys/module/msm_performance/parameters/enabled 2>/dev/null",
            // 提权所有 CPU 频率
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do echo \$(cat \$(dirname \$d)/cpufreq/cpuinfo_max_freq) > \$d 2>/dev/null; done",
            // GPU 锁最高档
            "echo '0' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null",
            "echo '0' > /sys/class/kgsl/kgsl-3d0/default_pwrlevel 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null",
            // devfreq GPU 锁满频
            "for d in /sys/class/devfreq/*gpu* /sys/class/devfreq/*kgsl*; do [ -f \$d/min_freq ] && max=\$(cat \$d/max_freq 2>/dev/null) && [ -n \"\$max\" ] && [ \"\$max\" != \"0\" ] && echo \$max > \$d/min_freq 2>/dev/null; done",
            // 关闭 MIUI 温控
            "echo '0' > /sys/module/msm_thermal/core_control/enabled 2>/dev/null",
            "echo 'N' > /sys/module/msm_thermal/parameters/enabled 2>/dev/null",
            // MIUI perfd 参数
            "echo '0' > /proc/sys/walt/sched_boost 2>/dev/null",
            // 清除 I/O 统计以提速
            "echo 'noop' > /sys/block/mmcblk0/queue/scheduler 2>/dev/null",
            "echo 'noop' > /sys/block/mmcblk1/queue/scheduler 2>/dev/null",
            "echo '2048' > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null",
            "echo '2048' > /sys/block/mmcblk1/queue/read_ahead_kb 2>/dev/null",
        )
        var anySuccess = false
        for (cmd in cmds) {
            if (RootShell.execOk(cmd)) anySuccess = true
        }
        return anySuccess
    }

    /** 恢复调度（关闭接管，让系统回归默认） */
    suspend fun disableSchedulingTakeover(): Boolean {
        val cmds = listOf(
            "start perfd 2>/dev/null",
            "start miuibooster 2>/dev/null",
            "start vendor.perfservice 2>/dev/null",
            "start thermal-engine 2>/dev/null",
            // 恢复 CPU 默认调度
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do echo '0' > \$d 2>/dev/null; done",
        )
        var ok = false
        for (cmd in cmds) {
            if (RootShell.execOk(cmd)) ok = true
        }
        return ok
    }

    /** 检查调度接管是否激活 */
    suspend fun isTakeoverActive(): Boolean {
        // 看 min_pwrlevel 是否被改了
        val lvl = RootShell.readFile("/sys/class/kgsl/kgsl-3d0/min_pwrlevel")
        return lvl == "0"
    }

    // ====== FPS 监控 ======
    /** 读取当前 FPS（从 SurfaceFlinger） */
    suspend fun getCurrentFPS(): Int {
        // 读取 /sys/kernel/debug/dri/0/state 或通过 dumpsys
        val out = RootShell.exec("dumpsys surfaceflinger 2>/dev/null | grep -m1 'SurfaceFlinger'")
        val m = Regex("(\\d+)").find(out)
        return m?.value?.toIntOrNull() ?: 0
    }

    // ====== 系统信息 ======
    suspend fun getSoCName(): String {
        val platform = RootShell.readFile("getprop ro.board.platform")
        val board = RootShell.readFile("getprop ro.product.board")
        return if (platform.isNotBlank()) platform else (if (board.isNotBlank()) board else "unknown")
    }

    suspend fun getCPUModel(): String {
        val raw = RootShell.readFile("/proc/cpuinfo")
        val m = Regex("Hardware\\s*:\\s*(.+)").find(raw)
        return m?.groupValues?.get(1)?.trim() ?: "unknown"
    }
}
